package projet.servlets;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Fichier
 */
@WebServlet("/Fichier")
public class Fichier extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final String VUE = "/Site/Fichier.jsp";

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public Fichier() {
		super();
		// TODO Auto-generated constructor stub
	}


	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String chaine="";
		 System.out.println("Working Directory = " +  System.getProperty("user.dir"));
		try{
			File f = new File("fichiers/texte.txt");
			System.out.println("Chemin absolu du fichier : " + f.getAbsolutePath());

		    System.out.println("Nom du fichier : " + f.getName());

		    System.out.println("Est-ce qu'il existe ? " + f.exists());

		    System.out.println("Est-ce un r�pertoire ? " + f.isDirectory());

		    System.out.println("Est-ce un fichier ? " + f.isFile());
		}
		catch (Exception e){
			System.out.println("ERREUR FILE "+e.toString());
		}
		try{
			
			BufferedReader br=new BufferedReader(new FileReader("fichiers/texte.txt"));
			String ligne;
			while ((ligne=br.readLine())!=null){
				System.out.println(ligne);
				chaine+=ligne+"\n";
			}
			br.close(); 
		}		
		catch (Exception e){
			System.out.println("ERREUR BUFFER "+e.toString());
		}
		try {
			BufferedWriter bw = new BufferedWriter (new FileWriter ("test.txt"));
			PrintWriter fichierSortie = new PrintWriter (bw); 
			fichierSortie.println (chaine+"\n test de lecture et �criture !!"); 
			fichierSortie.close();
			System.out.println("Le fichier test.txt a �t� cr��!"); 
		}
		catch (Exception e){
			System.out.println(e.toString());
		}	
		this.getServletContext().getRequestDispatcher( VUE ).forward( request, response );
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
